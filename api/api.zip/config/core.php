<?php

if($_SERVER['HTTP_HOST']=='localhost'){
	define('APPLICATION_URL', 'http://localhost/flooopadmin/');
	define('PROJECT_ROOT_PATH', 'C:\xampp\htdocs\flooopadmin');
}
if($_SERVER['HTTP_HOST']=='answebtechnologies.in' || $_SERVER['HTTP_HOST']=='www.answebtechnologies.in'){
	if($_SERVER['HTTP_HOST']=='answebtechnologies.in'){
		define('APPLICATION_URL', 'https://answebtechnologies.in/flooopadmin/');
	}
	if($_SERVER['HTTP_HOST']=='www.answebtechnologies.in'){
		define('APPLICATION_URL', 'https://www.answebtechnologies.in/flooopadmin/');
	}
	define('PROJECT_ROOT_PATH', '/home/axomaxjq/domains/answebtechnologies.in/public_html/flooopadmin');
}
if($_SERVER['HTTP_HOST']=='idealfitness.in' || $_SERVER['HTTP_HOST']=='www.idealfitness.in'){
	if($_SERVER['HTTP_HOST']=='idealfitness.in'){
		define('APPLICATION_URL', 'http://idealfitness.in/');
	}
	if($_SERVER['HTTP_HOST']=='www.idealfitness.in'){
		define('APPLICATION_URL', 'http://www.idealfitness.in/');
	}
}

// set your default time-zone
date_default_timezone_set('Asia/Kolkata');
 
// variables used for jwt
$key = "example_key";
$issued_at = time();
$expiration_time = $issued_at + (60 * 60); // valid for 1 hour
$issuer = "https://answebtechnologies.in/flooop/";

?>